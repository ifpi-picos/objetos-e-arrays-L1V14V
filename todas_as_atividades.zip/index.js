//Crie um array de números de 1 a 10 e use forEach para imprimir cada número no console.


const numeros = [1,2,3,4,5,6,7,8,9,10];

numeros.forEach((numeros) =>
 console.log(numeros)
);
