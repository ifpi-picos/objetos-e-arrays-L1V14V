//Crie um array de objetos representando carros, cada um com propriedades nome e ano, e use filter para criar um novo array contendo apenas os carros fabricados após o ano 2010.

const carro = [{
   nome: 'Volkswagen',
   ano: 2020,
},{
  nome:'civic',
  ano: 2008
},{
  nome:'gol',
  ano: 2011
}];

const carrosAno2010 = carro.filter((carr) => {return carr.ano > 2010});

console.log(carrosAno2010)