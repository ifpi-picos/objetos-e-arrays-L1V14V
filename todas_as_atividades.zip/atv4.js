//Crie um array de frutas e use includes para verificar se a fruta "maçã" está presente no array.

const fruit = ['maçã','banana','uva']

console.log(fruit.includes('maçã'))