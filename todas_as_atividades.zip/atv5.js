//Crie um array de objetos representando pessoas com nome e idade, e use find para encontrar a primeira pessoa com idade maior que 18.

const pessoa = [
  {nome: ' luis', idade: 14},
  {nome:'livia',idade : 19},
  {nome: 'pedro',idade: 15},]

const encontrarPessoa = pessoa.find((pe) => pe.idade > 18)

console.log(encontrarPessoa)