//Crie uma função que recebe um nome completo do usuário e imprime somente o primeiro nome.

function NameComplet(nomeCompleto) {
  const partes = nomeCompleto.split(' ');
  
  const primeiroNome = partes[0];
  
  console.log( primeiroNome);

}
const nomeCompleto = 'Ana Lívia Farias'
NameComplet(nomeCompleto)