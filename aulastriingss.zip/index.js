//Crie uma string com o seu nome e imprima o número de caracteres.

const nome = 'Ana Lívia';

console.log(`Este é meu nome: ${nome}`)