//Crie uma função que recebe um nome completo do usuário e imprime o primeiro e último nome.

function NameComplet(nomeCompleto) {
  const partes = nomeCompleto.split(' ');

  const primeiroNome = partes[0];

  const ultimoNome = partes[partes.length - 1];

  console.log( primeiroNome);
  console.log(ultimoNome);
  
}

const nomeCompleto = 'Ana Lívia Farias'
NameComplet(nomeCompleto)