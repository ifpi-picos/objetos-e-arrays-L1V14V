//Crie uma string com uma frase e use o método `toUpperCase` para imprimir a frase em letras maiúsculas.


const frase = 'olá pessoal!'

const novaFrase = frase.toUpperCase()

console.log(novaFrase)
3squ1s0fr3ni4